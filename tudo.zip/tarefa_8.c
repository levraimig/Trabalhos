#include<stdbool.h>
#include<stdio.h>
#include<stdlib.h>

#define PREMISES_SIZE 2
#define CONSEQUENCE_SIZE 4


bool tarefa_8 (bool P, bool Q)
 {  
     bool valor=false;

      if ((!P && Q)==true)
         { 

           valor=true;
         } else
               {
                 valor=false;
               }

      return valor;

}

 
int main() {
    bool ps[PREMISES_SIZE] = {false, true};
    bool qs[PREMISES_SIZE] = {false, true};
    bool answer[CONSEQUENCE_SIZE] = {false, true, false, false};

    bool alright = true;

    printf("Tarefa 8: ~P && Q\n");
    for(int i = 0; i < PREMISES_SIZE; i++) {
        for(int j = 0; j < PREMISES_SIZE; j++) {
            if(tarefa_8(ps[i], qs[j]) == answer[i * PREMISES_SIZE + j]) {
                printf("    Correto: ");
            } else {
                printf("  Incorreto: ");
                alright = false;
            }
            printf("~(%d) && %d = %d\n", ps[i], qs[j], answer[i * PREMISES_SIZE + j]);
        }
    }
    return !alright;
}
                
