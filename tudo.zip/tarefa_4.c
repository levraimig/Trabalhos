#include <stdbool.h>
#include<stdio.h>
#include<stdlib.h>

#define PREMISES_SIZE 2
#define CONSEQUENCE_SIZE 16

bool tarefa_4 (bool P, bool Q, bool R, bool S)
 {  
     bool valor=false;

      if (((P && Q) == true) || ((R && S) == true)) 
         { 

           valor=true;
         } else
               {
                 valor=false;
               }

      return valor;
}
int main() {
    bool ps[PREMISES_SIZE] = {false, true};
    bool qs[PREMISES_SIZE] = {false, true};
    bool rs[PREMISES_SIZE] = {false, true};
    bool ss[PREMISES_SIZE] = {false, true};
    bool answer[CONSEQUENCE_SIZE] = {
        false, false, false, true,
        false, false, false, true,
        false, false, false, true,
        true, true, true, true
    };

    bool alright = true;
int i=0, j=0, k=0, l=0;
    printf("Tarefa 4: (P && Q) || (R && S)\n");
    for( i = 0; i < PREMISES_SIZE; i++) {
        for( j = 0; j < PREMISES_SIZE; j++) {
            for( k = 0; k < PREMISES_SIZE; k++) {
                for( l = 0; l < PREMISES_SIZE; l++) {
                    if(tarefa_4(ps[i], qs[j], rs[k], ss[l]) == answer[
                            i * PREMISES_SIZE * PREMISES_SIZE * PREMISES_SIZE +
                            j * PREMISES_SIZE * PREMISES_SIZE +
                            k * PREMISES_SIZE +
                            l
                        ]
                    ) {
                        printf("    Correto: ");
                    } else {
                        printf("  Incorreto: ");
                        alright = false;
                    }
                    printf(
                            "(%d && %d) || (%d && %d) = %d\n",
                            ps[i], qs[j], rs[k], ss[l], answer[
                                    i * PREMISES_SIZE * PREMISES_SIZE * PREMISES_SIZE +
                                    j * PREMISES_SIZE * PREMISES_SIZE +
                                    k * PREMISES_SIZE +
                                    l
                            ]
                    );
                }
            }
        }
    }
    return !alright;
}