#include<stdbool.h>
#include<stdio.h>
#include<stdlib.h>

#define PREMISES_SIZE 2
#define CONSEQUENCE_SIZE 16


bool tarefa_10 (bool P, bool Q, bool R, bool S)
 {  
     bool valor=false;

      if (!(((P && Q) == true) || ((R && S) == true)) )
         { 

           valor=true;
         } else
               {
                 valor=false;
               }

      return valor;

}

 
int main() {
    bool ps[PREMISES_SIZE] = {false, true};
    bool qs[PREMISES_SIZE] = {false, true};
    bool rs[PREMISES_SIZE] = {false, true};
    bool ss[PREMISES_SIZE] = {false, true};
    bool answer[CONSEQUENCE_SIZE] = {
            true, true, true, false,
            true, true, true, false,
            true, true, true, false,
            false, false, false, false
    };

    bool alright = true;

    printf("Tarefa 10: ~((P && Q) || (R && S))\n");
    for(int i = 0; i < PREMISES_SIZE; i++) {
        for(int j = 0; j < PREMISES_SIZE; j++) {
            for(int k = 0; k < PREMISES_SIZE; k++) {
                for(int l = 0; l < PREMISES_SIZE; l++) {
                    if(tarefa_10(ps[i], qs[j], rs[k], ss[l]) == answer[
                            i * PREMISES_SIZE * PREMISES_SIZE * PREMISES_SIZE +
                            j * PREMISES_SIZE * PREMISES_SIZE +
                            k * PREMISES_SIZE +
                            l
                    ]
                            ) {
                        printf("    Correto: ");
                    } else {
                        printf("  Incorreto: ");
                        alright = false;
                    }
                    printf(
                            "~((%d && %d) || (%d && %d)) = %d\n",
                            ps[i], qs[j], rs[k], ss[l], answer[
                                    i * PREMISES_SIZE * PREMISES_SIZE * PREMISES_SIZE +
                                    j * PREMISES_SIZE * PREMISES_SIZE +
                                    k * PREMISES_SIZE +
                                    l
                            ]
                    );
                }
            }
        }
    }
    return !alright;
}